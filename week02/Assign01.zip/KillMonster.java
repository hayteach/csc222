// This program creates 2 monsters, one "Generic" and one user defined
// The 2 monsters then battle "to the death" using the method defined in Monster for "battle"

// both Monster info is printed before and after the battle to check how it worked

import java.util.Scanner;

public class KillMonster 
{
    // create an input scanner that can be used in the program or any static methods
   static Scanner kb = new Scanner(System.in);
    public static void main(String[] args) 
    {
        
        // collect input on the first monster
        System.out.println("Please enter your monster's name");
        String mon1Name = kb.nextLine();
        System.out.println("\nPlease enter the Monster' type:");
        String mon1Type = kb.nextLine();
        System.out.println("\nPlease enter the Monster's number of lives:");
        int mon1Lives = kb.nextInt();
        kb.nextLine();

        //Use a static method to make sure that health is an integer
        int mon1Health = getMonHealth();
        kb.nextLine();

        // create the first monster
        Monster mon1 = new Monster(mon1Name, mon1Type, mon1Lives, mon1Health);

        // get the name of the generic monster and create that monster
        System.out.println("Please enter the Generic Monster's name:");
        String genMon = kb.nextLine();
        Monster generic = new Monster(genMon);

        // print out information on both monsters
        System.out.println("\n****** Pre-Battle Status *****\n");
        mon1.printMonster();
        generic.printMonster();

        // have the 2 monsters battle until 1 of them loses a life
        // NOTE: I coded this for example only so I did not work on
        // what happens when the Monster runs out of lives so only
        // good for when a Monster has at least 1 extra life to start with
        boolean victor = mon1.battle(generic);

        if (victor)
        {
            System.out.println("Congratulations! Monster 1 is the Winner!!!!");
        }
        else
        {
            System.out.println("Generic is the Winner");
        }

        // Print out Monster stats after the Battle
        System.out.println("\n***** Post-Battle Status *****");
        mon1.printMonster();
        generic.printMonster();


        // close and normally exit the program
        kb.close();
        System.exit(0);


    }


    // Static method used to collect the integer for the monsters health
    // Loops until a valid entry 
    // NOTE: At this point, only check for an integer. 
    // For a "complete" method, would need to add a check for health greater than 0 and 
    // not over the maximum value allowed
    public static int getMonHealth()
    {
        System.out.println("\nPlease enter the Monster's current health");
        boolean done = false;
        int monHealth = 0;
        while (!done)
        {
            try {
                monHealth = kb.nextInt();
                done = true;
            } catch (Exception e) {
                //TODO: handle exception
                System.out.println("You must enter an integer!");
                kb.nextLine();
            }
        }
        
        return monHealth;
        
    }

    
}
