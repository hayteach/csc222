/* 
    This code was originally submitted as an assignment by the student below.
    This code was modified by the instructor for use as a basis for an
    assignment in Programming II (CSC222)

    Instructor: David Pai
    Modification Date: 1/25/2022
    Modifications made:
        Changed code to not use the keyword "this" - personal preferance
        Added a "Generic" monster constructor
        Added a "battle" method so this Monster can "battle" a second Monster until one or the other loses a life

    File: Monster.java
   Name: Zechariah Dean
   Email: Zechariah.Dean@student.mendocino.edu
   Date: 9/29/21
   Course: CSC 221L - Programming 1 Lab
   Desc: Program exports Monster class which defines what a monster can do
         and the attributes thereof.
*/
import java.util.Random;

class Monster
{
    //attributes for monsters
    private String name;
    private String type;
    private int lives;
    private int health;

    //the main constructor for monsters
    Monster(String aName, String aType, int aLives, int aHealth)
    {
        name = aName;
        type = aType;
        lives = aLives;
        health = aHealth;
    }
    // a "Generic" monster with 2 lives
    Monster(String aName)
    {
        name = aName;
        type = "Generic";
        lives = 2;
        health = 100;
    }

    //get methods
    public String getName()
    {
        return name;
    }
    
    public String gettype()
    {
        return type;
    }

    public int getLives()
    {
        return lives;
    }
    public int getHP()
    {
        return health;
    }

    //set methods
    public void setName(String aName)
    {
        name = aName;
    }
    public void setAttribute(String newType)
    {
        type = newType;
    }
    public void setLives(int newSTR)
    {
        lives = newSTR;
    }
    public void setHP(int newHP)
    {
        health = newHP;
    }
    
    //method to print the monster's attributes
    public void printMonster()
    {
        System.out.println("Name: " + name);
        System.out.println("Type: " + type);
        System.out.println("Lives: " + lives);
        System.out.println("HP: " + health + "\n");
    }
    
    //method for one monster to battle another
    //When "this" monster wins, method returns "true"
    // when the other monster wins, method returns "false"
    public boolean battle(Monster otherMon)
    {
        Random r = new Random();
        boolean done = false;
        // let the battle begin
        while (!done)
        {
            // create a random int from 1-25 for how much damage "this" monster does to the "otherMon"
            int damage = r.nextInt(25) + 1;
            int otherHealth = otherMon.getHP() - damage;
            if (otherHealth <= 0)
            {
                otherMon.setLives(otherMon.getLives() - 1);
                otherMon.setHP(100);
                done = true;
                return true;
            }
            else
            {
                otherMon.setHP(otherHealth);
                damage = r.nextInt(25) + 1;
                int myHealth = health - damage;
                if (myHealth <= 0)
                {
                    lives--;
                    health = 100;
                    done = true;
                    return false;
                }
                else
                {
                    health = myHealth;
                }
            }
        }
        
        return true;
    }

}